/*Driver App Configuration*/

var krms_driver_config ={			
	'ApiUrl':"http://guiarango.com.br/driver/api",		
	'DialogDefaultTitle':"DriverApp",
	'mapboxToken' : 'pk.eyJ1IjoiY2xlaXNzb25jYXJkb3NvIiwiYSI6ImNqcXFwbnB3MTBldW80OHFqemJxbWltdTgifQ.kHXCoL-BHBMhIbPcvuv9-Q',
	'APIHasKey':"df284e28ad6eb6e254fa12b787831806",
	'debug': true
};